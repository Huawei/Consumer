/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.huawei.hms.wallet.util;

import android.util.Base64;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;


public class RSA {

    /**
     * Signature algorithm
     */
    public static final String SIGN_ALGORITHMS256 = "SHA256WithRSA";

    private static final String RSA_ECB_OAEP_SHA256_ALGORITHM = "RSA/ECB/OAEPwithSHA-256andMGF1Padding";

    /**
     * RSA Sign
     *
     * @param content    Sign Data
     * @param privateKey Merchant private Key
     * @return Sign value
     */
    public static String sign(String content, String privateKey, String signType) {
        String charset = "utf-8";
        try {
            PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.decode(privateKey,Base64.DEFAULT));
            KeyFactory keyf = KeyFactory.getInstance("RSA");
            PrivateKey priKey = keyf.generatePrivate(priPKCS8);

            java.security.Signature signatureObj = java.security.Signature.getInstance(SIGN_ALGORITHMS256);
            signatureObj.initSign(priKey);
            signatureObj.update(content.getBytes(charset));

            byte[] signed = signatureObj.sign();
            return Base64.encodeToString(signed,Base64.DEFAULT);
        } catch (Exception ex) {
            System.out.println(ex);
        }

        return "";
    }

    /**
     * Verify Sign
     *
     * @param content   Sign Content
     * @param sign      Sign value
     * @param publicKey public Key
     * @param signType  Sign Type
     * @return Sign success or failed
     */
    public static boolean doCheck(byte[] content, String sign, String publicKey, String signType) {
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] encodedKey = Base64.decode(publicKey,Base64.DEFAULT);
            PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));

            java.security.Signature signature = java.security.Signature.getInstance(SIGN_ALGORITHMS256);
            signature.initVerify(pubKey);
            signature.update(content);

            boolean bverify = signature.verify(Base64.decode(sign,Base64.DEFAULT));
            return bverify;

        } catch (Exception e) {
            System.out.println(e);
        }

        return false;
    }

}
