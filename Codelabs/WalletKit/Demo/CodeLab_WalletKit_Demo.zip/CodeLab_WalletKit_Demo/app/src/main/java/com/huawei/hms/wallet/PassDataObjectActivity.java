package com.huawei.hms.wallet;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.huawei.hms.api.ConnectionResult;
import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.maps.model.LatLng;
import com.huawei.hms.wallet.apptest.R;
import com.huawei.hms.wallet.base.LabelInfo;
import com.huawei.hms.wallet.base.LabelInfoRow;
import com.huawei.hms.wallet.base.LoyaltyPoints;
import com.huawei.hms.wallet.base.LoyaltyPointsBalance;
import com.huawei.hms.wallet.base.TextComponentInfo;
import com.huawei.hms.wallet.base.TimeDuration;
import com.huawei.hms.wallet.base.UriInfo;
import com.huawei.hms.wallet.base.WalletPassConstants;
import com.huawei.hms.wallet.base.WalletPassMessage;
import com.huawei.hms.wallet.util.BasisTimesUtils;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;


public class PassDataObjectActivity extends Activity
        implements HuaweiApiClient.OnConnectionFailedListener {
    private static final String TAG = "PassDataObjectActivity";
    public static final int SAVE_TO_ANDROID = 888;
    // 积分类型的下拉框
    private Spinner spinnerPoints;
    private List<String> pointsTypelist;
    private ArrayAdapter<String> pointsAdapter;
    private int pointsTypeIndext;
    // passObject状态下拉框
    private Spinner spinner;
    private List<String> data_list;
    private ArrayAdapter<String> arr_adapter;
    int indext;
    private  String startTime = "";
    private  String endTime = "";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pass_info);

        Button button = findViewById(R.id.clickSaveData);
        //积分类型的下拉框
        spinnerPoints = findViewById(R.id.spinnerPoints);
        //数据
        pointsTypelist = new ArrayList<String>();
        pointsTypelist.add("INT");
        pointsTypelist.add("DOUBLE");
        pointsTypelist.add("STRING");
        pointsTypelist.add("MONEY");
        pointsTypelist.add("UNDEFINED");
        //适配器
        pointsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, pointsTypelist);
        //设置样式
        pointsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //加载适配器
        spinnerPoints.setAdapter(pointsAdapter);
        spinnerPoints.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {//选择item的选择点击监听事件
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                // 获取选择状态索引值
                pointsTypeIndext = arg2;
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
        //passObject状态下拉框
        spinner = (Spinner) findViewById(R.id.spinner);
        //数据
        data_list = new ArrayList<String>();
        data_list.add("ACTIVE");
        data_list.add("COMPLETED");
        data_list.add("EXPIRED");
        data_list.add("INACTIVE");
        //适配器
        arr_adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, data_list);
        //设置样式
        arr_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //加载适配器
        spinner.setAdapter(arr_adapter);

        spinner.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {//选择item的选择点击监听事件
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                // 获取选择状态索引值
                indext = arg2;
            }

            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView passTypeId = findViewById(R.id.passTypeId);
                String typeId = passTypeId.getText().toString();
                if (TextUtils.isEmpty(typeId)) {
                    Toast.makeText(PassDataObjectActivity.this, "passTypeId为空", Toast.LENGTH_LONG).show();
                    return;
                }


                TextView issuerIdView = findViewById(R.id.issuerId);
                String issuerId = issuerIdView.getText().toString();
                if (TextUtils.isEmpty(issuerId)) {
                    Toast.makeText(PassDataObjectActivity.this, "issuerId为空", Toast.LENGTH_LONG).show();
                    return;
                }

                EditText mCardNumber = findViewById(R.id.cardNumber);
                TextView cardNumberText = findViewById(R.id.cardNumberText);
                String cardNumber = mCardNumber.getText().toString();
                if (TextUtils.isEmpty(cardNumber)) {
                    Toast.makeText(PassDataObjectActivity.this, cardNumberText.getText().toString() + "为空", Toast.LENGTH_LONG).show();
                    return;
                }

                EditText mAccountName = findViewById(R.id.accountName);
                TextView accountNameText = findViewById(R.id.accountNameText);
                String accountName = mAccountName.getText().toString();
                if (TextUtils.isEmpty(accountName)) {
                    Toast.makeText(PassDataObjectActivity.this, accountNameText.getText().toString() + "为空", Toast.LENGTH_LONG).show();
                    return;
                }


                EditText mBarcodeAlternateText = findViewById(R.id.barcodeAlternateText);
                EditText mBarcodeType = findViewById(R.id.barcodeType);
                EditText mBarcodeValue = findViewById(R.id.barcodeValue);
                EditText mPassStyleIdentifier = findViewById(R.id.passStyleIdentifier);

                //serinumber
                EditText mOrganizationPassId = findViewById(R.id.organizationPassId);
                TextView organizationPassIdText = findViewById(R.id.organizationPassIdText);
                String organizationPassId = mOrganizationPassId.getText().toString();
                if (TextUtils.isEmpty(organizationPassId)) {
                    Toast.makeText(PassDataObjectActivity.this, organizationPassIdText.getText().toString() + "为空", Toast.LENGTH_LONG).show();
                    return;
                }

                //图片模块主图片URI
                EditText mImageModuleDataMainImageUris = findViewById(R.id.imageModuleDataMainImageUris);
                EditText mImageModuleDataMainImageUrisDes = findViewById(R.id.imageModuleDataMainImageUrisDes);
                EditText mImageModuleDataMainImageUris1 = findViewById(R.id.imageModuleDataMainImageUris1);
                EditText mImageModuleDataMainImageUrisDes1 = findViewById(R.id.imageModuleDataMainImageUrisDes1);

                //发卡方名字
                EditText mIssuerName = findViewById(R.id.issuerName);
                TextView issuerNameText = findViewById(R.id.IssuerName);
                String issuerName = mIssuerName.getText().toString();
                if (TextUtils.isEmpty(issuerName)) {
                    Toast.makeText(PassDataObjectActivity.this, issuerNameText.getText().toString() + "为空", Toast.LENGTH_LONG).show();
                    return;
                }

                //模块URI
                EditText homepageUriKey = findViewById(R.id.homepageUriKey);
                EditText homepageUriLable = findViewById(R.id.homepageUriLable);
                EditText homepageUriValue = findViewById(R.id.homepageUriValue);
                String homepageKey =  homepageUriKey.getText().toString();
                String homepageLable =  homepageUriLable.getText().toString();
                String homepageValue =  homepageUriValue.getText().toString();



                EditText nearbyLocationsKey = findViewById(R.id.nearbyLocationsKey);
                EditText nearbyLocationsLable = findViewById(R.id.nearbyLocationsLable);
                EditText nearbyLocationsValue = findViewById(R.id.nearbyLocationsValue);
                String nearbyLocationsKeyStr =  nearbyLocationsKey.getText().toString();
                String nearbyLocationsLableStr =  nearbyLocationsLable.getText().toString();
                String nearbyLocationsValueStr =  nearbyLocationsValue.getText().toString();

                EditText hotlineKey = findViewById(R.id.hotlineKey);
                EditText hotlineLable = findViewById(R.id.hotlineLable);
                EditText hotlineValue = findViewById(R.id.hotlineValue);
                String hotlineKeyStr =  hotlineKey.getText().toString();
                String hotlineLableStr =  hotlineLable.getText().toString();
                String hotlineValueStr =  hotlineValue.getText().toString();

                EditText websiteKey = findViewById(R.id.websiteKey);
                EditText websiteLable = findViewById(R.id.websiteLable);
                EditText websiteValue = findViewById(R.id.websiteValue);
                String websiteKeyStr =  websiteKey.getText().toString();
                String websiteLableStr =  websiteLable.getText().toString();
                String websiteValueStr =  websiteValue.getText().toString();





                //经纬度
                EditText latitude = findViewById(R.id.latitude);
                EditText longitude = findViewById(R.id.longitude);
                EditText latitude1 = findViewById(R.id.latitude1);
                EditText longitude1 = findViewById(R.id.longitude1);


                //积分
                EditText Points = findViewById(R.id.points);

                //message消息
                EditText messageHeader = findViewById(R.id.messageHeader);
                EditText messageBody = findViewById(R.id.messageBody);
                EditText messageHeader1 = findViewById(R.id.messageHeader1);
                EditText messageBody1 = findViewById(R.id.messageBody1);


                // 项目的名称
                EditText mProgramName = findViewById(R.id.programName);
                String programName = mProgramName.getText().toString();
                if (TextUtils.isEmpty(programName)) {
                    Toast.makeText(PassDataObjectActivity.this, "项目的名称为空", Toast.LENGTH_LONG).show();
                    return;
                }

                //文本消息
                EditText textDataHeader = findViewById(R.id.textDataHeader);
                EditText textDataBody = findViewById(R.id.textDataBody);
                EditText textDataHeader1 = findViewById(R.id.textDataHeader1);
                EditText textDataBody1 = findViewById(R.id.textDataBody1);

                //位置校验
                Double latitud = 0.0;
                Double longitud = 0.0;
                String latitudeStr  = latitude.getText().toString();
                String longitudeStr = longitude.getText().toString();
                String latitudeStr1  = latitude1.getText().toString();
                String longitudeStr1 = longitude1.getText().toString();

                if (TextUtils.isEmpty(latitudeStr) || TextUtils.isEmpty(longitudeStr)) {
                    Toast.makeText(PassDataObjectActivity.this, "必填纬度或经度未输入", Toast.LENGTH_LONG).show();
                    return;

                } else {
                    if (-90.0D <= Double.valueOf(latitudeStr) && Double.valueOf(latitudeStr) <= 90.0D && -180.0D <= Double.valueOf(longitudeStr) && Double.valueOf(longitudeStr) <= 180.0D) {
                        latitud = Double.valueOf(latitudeStr);
                        longitud = Double.valueOf(longitudeStr);
                    } else {
                        Toast.makeText(PassDataObjectActivity.this, "必填纬度或经度超过范围", Toast.LENGTH_LONG).show();
                        return;
                    }
                }

                LatLng location = new LatLng(latitud, longitud);
                List<LatLng> locations = new ArrayList<>();
                locations.add(location);

                //构造积分
                EditText pointsEdit = findViewById(R.id.points);
                //构造积分
                LoyaltyPoints points = null;
                // 积分类型
                switch (pointsTypelist.get(pointsTypeIndext)) {
                    case "INT":
                        Integer pointInt;
                        if (TextUtils.isEmpty(pointsEdit.getText().toString()) || !Pattern.matches("^(\\|\\+)?\\d+(\\d+)?$", pointsEdit.getText().toString()) || pointsEdit.getText().toString().length() > 9) {
                            Toast.makeText(PassDataObjectActivity.this, "积分参数输入错误", Toast.LENGTH_LONG).show();
                            return;
                        } else {
                            pointInt = Integer.valueOf(pointsEdit.getText().toString());
                        }
                        points = LoyaltyPoints.newPassBuilder()
                                .setPointsLabel("Points")
                                .setPointsType("points")
                                .setPointsBalance(LoyaltyPointsBalance.newPassBuilder().setIntValue(pointInt).build()).build();
                        break;
                    case "STRING":
                        String pointString;
                        if (TextUtils.isEmpty(pointsEdit.getText().toString())) {
                            Toast.makeText(PassDataObjectActivity.this, "请输入积分值", Toast.LENGTH_LONG).show();
                            return;
                        }
                        pointString = pointsEdit.getText().toString();
                        points = LoyaltyPoints.newPassBuilder()
                                .setPointsLabel("Points")
                                .setPointsType("points")
                                .setPointsBalance(LoyaltyPointsBalance.newPassBuilder().setStringValue(pointString).build()).build();
                        break;
                    case "DOUBLE":
                        Double pointDouble ;
                        if (TextUtils.isEmpty(pointsEdit.getText().toString()) || !Pattern.matches("^[+]?[0-9.]+$", pointsEdit.getText().toString()) || pointsEdit.getText().toString().length() >15) {
                            Toast.makeText(PassDataObjectActivity.this, "积分参数输入错误", Toast.LENGTH_LONG).show();
                            return;
                        } else {
                            pointDouble = Double.valueOf(pointsEdit.getText().toString());
                        }
                        points = LoyaltyPoints.newPassBuilder()
                                .setPointsLabel("Points")
                                .setPointsType("points")
                                .setPointsBalance(LoyaltyPointsBalance.newPassBuilder().setDoubleValue(pointDouble).build()).build();
                        break;
                    case "MONEY":
                        String pointMoney;
                        if (TextUtils.isEmpty(pointsEdit.getText().toString())) {
                            Toast.makeText(PassDataObjectActivity.this, "请输入积分值", Toast.LENGTH_LONG).show();
                            return;
                        }
                        pointMoney = pointsEdit.getText().toString();
                        points = LoyaltyPoints.newPassBuilder()
                                .setPointsLabel("Points")
                                .setPointsType("points")
                                .setPointsBalance(LoyaltyPointsBalance.newPassBuilder().setStringValue(pointMoney).build()).build();
                        break;
                    case "UNDEFINED":
                        points = LoyaltyPoints.newPassBuilder()
                                .setPointsLabel("Points")
                                .setPointsType("points")
                                .setPointsBalance(LoyaltyPointsBalance.newPassBuilder().setStringValue("").build())
                                .build();
                }

                //状态
                int state = 1;
                switch (data_list.get(indext)) {
                    case "ACTIVE":
                        state = WalletPassConstants.PassState.ACTIVE;
                        break;
                    case "COMPLETED":
                        state = WalletPassConstants.PassState.COMPLETED;
                        break;
                    case "EXPIRED":
                        state = WalletPassConstants.PassState.EXPIRED;
                        break;
                    case "INACTIVE":
                        state = WalletPassConstants.PassState.INACTIVE;
                }


                //有效的时间间隔
                Long start = 0L;
                Long end = 0L;
                Date date = new Date();
                Calendar ca = Calendar.getInstance();
                ca.setTime(date);
                if (TextUtils.isEmpty(startTime)) {
                    ca.add(Calendar.DATE,1);
                    start = ca.getTimeInMillis();
                    Toast.makeText(PassDataObjectActivity.this, "开始时间未选择", Toast.LENGTH_LONG).show();
                    return;
                }else {
                    start = BasisTimesUtils.getLongTimeOfYMD(startTime);
                }

                if (TextUtils.isEmpty(endTime)) {
                    ca.add(Calendar.DATE,2);
                    end = ca.getTimeInMillis();
                    Toast.makeText(PassDataObjectActivity.this, "失效时间未选择", Toast.LENGTH_LONG).show();
                    return;
                }else {
                    end = BasisTimesUtils.getLongTimeOfYMD(endTime);
                }

                if (end <=start || end <= date.getTime()){
                    Toast.makeText(PassDataObjectActivity.this, "结束时间必须大于开始时间并且大于当前时间", Toast.LENGTH_LONG).show();
                    return;
                }
                TimeDuration mValidTimeDuration = new TimeDuration(start,end);

                LoyaltyWalletObject.PassBuilder builder=   LoyaltyWalletObject.newPassBuilder();
                builder.setPassTypeIdentifier(typeId)
                        .setPassAccountName(accountName)
                        .setCardNumber(cardNumber)
                        .setPassBarcodeAlternateText(mBarcodeAlternateText.getText().toString())
                        .setPassBarcodeType(mBarcodeType.getText().toString())
                        .setPassBarcodeValue(mBarcodeValue.getText().toString())
                        .setPassStyleIdentifier(mPassStyleIdentifier.getText().toString())
                        .setOrganizationPassId(organizationPassId)
                        .setPassIssuerName(issuerName)
                        .setPoints(points)
                        .setPassProgramName(programName)
                        .setPassState(state)
                        .setPassTimeDuration(mValidTimeDuration);


                //图片模块主图片URI
                List uris = new ArrayList();
                String imageUris  = mImageModuleDataMainImageUris.getText().toString();
                String imageDes = mImageModuleDataMainImageUrisDes.getText().toString();
                String imageUris1  = mImageModuleDataMainImageUris1.getText().toString();
                String imageDes1 = mImageModuleDataMainImageUrisDes1.getText().toString();
                if (!TextUtils.isEmpty(imageUris) && !TextUtils.isEmpty(imageDes) && TextUtils.isEmpty(imageUris1) && TextUtils.isEmpty(imageDes1)){
                   builder.addImage(new UriInfo(imageUris,imageDes));
                } else if (TextUtils.isEmpty(imageUris) && TextUtils.isEmpty(imageDes) && !TextUtils.isEmpty(imageUris1) && !TextUtils.isEmpty(imageDes1)){
                    builder.addImage(new UriInfo(imageUris1,imageDes1));
                }else  if (!TextUtils.isEmpty(imageUris) && !TextUtils.isEmpty(imageDes) && !TextUtils.isEmpty(imageUris1) && !TextUtils.isEmpty(imageDes1)){
                    new UriInfo(imageUris1,imageDes1);
                    uris.add(new UriInfo(imageUris,imageDes));
                    uris.add(new UriInfo(imageUris1,imageDes1));
                    builder.addImageList(uris);
                }else {
//                    Toast.makeText(PassDataObjectActivity.this, "至少有一个完整的image", Toast.LENGTH_LONG).show();
                }

                //加入成功后显示文本钱包对象消息
                List messages = new ArrayList();
                String mgeHeader  = messageHeader.getText().toString();
                String mgeBody = messageBody.getText().toString();
                String mgeHeader1  = messageHeader1.getText().toString();
                String mgeBody1 = messageBody1.getText().toString();
                if (!TextUtils.isEmpty(mgeHeader) && !TextUtils.isEmpty(mgeBody) && TextUtils.isEmpty(mgeHeader1) && TextUtils.isEmpty(mgeBody1)){
                    WalletPassMessage message = WalletPassMessage.newBuilder()
                            .setTitle(mgeHeader)
                            .setContent(mgeBody)
                            .build();
                    builder.addMessage(message);
                } else if (TextUtils.isEmpty(mgeHeader) && TextUtils.isEmpty(mgeBody) && !TextUtils.isEmpty(mgeHeader1) && !TextUtils.isEmpty(mgeBody1)){
                    WalletPassMessage  message = WalletPassMessage.newBuilder()
                            .setTitle(mgeHeader1)
                            .setContent(mgeBody1)
                            .build();
                    builder.addMessage(message);

                }else  if (!TextUtils.isEmpty(mgeHeader) && !TextUtils.isEmpty(mgeBody) && !TextUtils.isEmpty(mgeHeader1) && !TextUtils.isEmpty(mgeBody1)){
                    messages.add(WalletPassMessage.newBuilder()
                            .setTitle(mgeHeader)
                            .setContent(mgeBody)
                            .build());
                    messages.add(WalletPassMessage.newBuilder()
                            .setTitle(mgeHeader1)
                            .setContent(mgeBody1)
                            .build());
                    builder.addMessageList(messages);
                }else {
//                    Toast.makeText(PassDataObjectActivity.this, "至少有一个完整的message", Toast.LENGTH_LONG).show();
                }

                //构建文本模块
                List textModulesData = new ArrayList();
                String textHeader  = textDataHeader.getText().toString();
                String textBody = textDataBody.getText().toString();
                String textHeader1  = textDataHeader1.getText().toString();
                String textBody1 = textDataBody1.getText().toString();
                if (!TextUtils.isEmpty(textHeader) && !TextUtils.isEmpty(textBody) && TextUtils.isEmpty(textHeader1) && TextUtils.isEmpty(textBody1)){
                    TextComponentInfo textModuleData = new TextComponentInfo(textHeader,textBody);
                    builder.addTextData(textModuleData);
                } else if (TextUtils.isEmpty(textHeader) && TextUtils.isEmpty(textBody) && !TextUtils.isEmpty(textHeader1) && !TextUtils.isEmpty(textBody1)){
                    TextComponentInfo textModuleData = new TextComponentInfo(textHeader1,textBody1);
                    builder.addTextData(textModuleData);

                }else if (!TextUtils.isEmpty(textHeader) && !TextUtils.isEmpty(textBody) && !TextUtils.isEmpty(textHeader1) && !TextUtils.isEmpty(textBody1)){
                    textModulesData.add(new TextComponentInfo(textHeader,textBody));
                    textModulesData.add(new TextComponentInfo(textHeader1,textBody1));
                    builder.addTextDataList(textModulesData);
                }else {
//                    Toast.makeText(PassDataObjectActivity.this, "至少有一个完整的textData", Toast.LENGTH_LONG).show();
                }

                //判断第二个位置是否为空 据此判断是添加集合还是添加单个

                if (TextUtils.isEmpty(latitudeStr1) || TextUtils.isEmpty(longitudeStr1)) {
                   builder.addPassLocation(location);
                } else {
                    if (-90.0D <= Double.valueOf(latitudeStr1) && Double.valueOf(latitudeStr1) <= 90.0D && -180.0D <= Double.valueOf(longitudeStr1) && Double.valueOf(longitudeStr1) <= 180.0D) {
                       double latitudSecond = Double.valueOf(latitudeStr1);
                      double  longitudSecond = Double.valueOf(longitudeStr1);
                      locations.add(new LatLng(latitudSecond,longitudSecond));
                      builder.addPassLocationList(locations);
                    } else {
                        Toast.makeText(PassDataObjectActivity.this, "可选的纬度或经度超过范围", Toast.LENGTH_LONG).show();
                        return;
                    }
                }


                //构建homepageUri  nearbyLocations hotline website

                if (!TextUtils.isEmpty(homepageKey) && !TextUtils.isEmpty(homepageLable) && !TextUtils.isEmpty(homepageValue)){
                   UriInfo homepageUri =  new UriInfo(homepageValue,homepageLable);
                   builder.addPassLinkUris(homepageKey, homepageUri);

                }

                if (!TextUtils.isEmpty(nearbyLocationsKeyStr) && !TextUtils.isEmpty(nearbyLocationsLableStr) && !TextUtils.isEmpty(nearbyLocationsValueStr)){
                    UriInfo nearbyLocations =  new UriInfo(nearbyLocationsValueStr,nearbyLocationsLableStr);
                    builder.addPassLinkUris(nearbyLocationsKeyStr, nearbyLocations);
                }

                if (!TextUtils.isEmpty(hotlineKeyStr) && !TextUtils.isEmpty(hotlineLableStr) && !TextUtils.isEmpty(hotlineValueStr)){
                    UriInfo hotline =  new UriInfo(hotlineValueStr,hotlineLableStr);
                    builder.addPassLinkUris(hotlineKeyStr, hotline);
                }

                if (!TextUtils.isEmpty(websiteKeyStr) && !TextUtils.isEmpty(websiteLableStr) && !TextUtils.isEmpty(websiteValueStr)){
                    UriInfo website =  new UriInfo(websiteValueStr,websiteLableStr);
                    builder.addPassLinkUris(websiteKeyStr, website);
                }

                LoyaltyWalletObject wob = builder.build();

                //显示方式声明Intent，直接启动SecondActivity
                Intent intent = new Intent(PassDataObjectActivity.this, PassTestActivity.class);
                intent.putExtra("passObject", wob.toJson());
                intent.putExtra("passId", organizationPassId);
                intent.putExtra("issuerId", issuerId);
                intent.putExtra("typeId", typeId);
                startActivity(intent);
            }
        });

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) { }

    public  void  selectStartTime(View view){
        // 获取日历对象
        Calendar calendar = Calendar.getInstance();
        // 获取当前对应的年、月、日的信息
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        // 获取当前时间信息
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);


        //选择时间
                BasisTimesUtils.showDatePickerDialog(PassDataObjectActivity.this, "true", year, month, day, new BasisTimesUtils.OnDatePickerListener() {
                    @Override
                    public void onConfirm(int year, int month, int dayOfMonth) {
                        startTime = String.valueOf(year)+"-"+String.valueOf(month)+"-"+String.valueOf(dayOfMonth);
                    }

                    @Override
                    public void onCancel() {
                        Toast.makeText(PassDataObjectActivity.this, "DatePickerDialog取消 ", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    public  void  selectEndTime(View view){
        // 获取日历对象
        Calendar calendar = Calendar.getInstance();
        // 获取当前对应的年、月、日的信息
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        // 获取当前时间信息
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        //选择时间
        BasisTimesUtils.showDatePickerDialog(PassDataObjectActivity.this, "true", year, month, day, new BasisTimesUtils.OnDatePickerListener() {
            @Override
            public void onConfirm(int year, int month, int dayOfMonth) {
                endTime = String.valueOf(year)+"-"+String.valueOf(month)+"-"+String.valueOf(dayOfMonth);
            }

            @Override
            public void onCancel() {
                Toast.makeText(PassDataObjectActivity.this, "DatePickerDialog取消 ", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
