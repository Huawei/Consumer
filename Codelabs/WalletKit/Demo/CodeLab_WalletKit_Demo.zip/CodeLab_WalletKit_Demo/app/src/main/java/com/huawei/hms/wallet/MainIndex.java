package com.huawei.hms.wallet;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;

import com.huawei.hms.api.ConnectionResult;
import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.wallet.apptest.R;


/**
 *
 * demo首页
 *
 * @author jwx850521
 * @since  2019/12/4
 */
public class MainIndex extends FragmentActivity   implements HuaweiApiClient.OnConnectionFailedListener {

    private static final String TAG = "MainIndex";
    public static final int SAVE_TO_ANDROID = 888;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.index_main);

    }


    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.w(TAG, "onConnectionFailed: " + connectionResult);
    }

    public void saveLoyaltyCard(View view){
        Intent intent = new Intent(this, PassDataObjectActivity.class);
        startActivity(intent);
    }

    public  void saveGiftCard(View view){
        Intent intent = new Intent(this, GiftCardActivity.class);
        startActivity(intent);
    }


    public  void saveCouponCard(View view){
        Intent intent = new Intent(this, CouponCardActivity.class);
        startActivity(intent);
    }

}
