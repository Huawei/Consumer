/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.huawei.hms.wallet;

import com.huawei.hms.wallet.apptest.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.huawei.hmf.tasks.Task;
import com.huawei.hms.api.ConnectionResult;
import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.wallet.util.JwtUtil;


import java.util.HashMap;
import java.util.Map;

/**
 * 测试DEMO的APP
 *
 * @author c00389330
 * @since 2019-11-06
 */
public class PassTestActivity extends FragmentActivity
        implements HuaweiApiClient.OnConnectionFailedListener {
    private static final String TAG = "TestActivity";
    public static final int SAVE_TO_ANDROID = 888;
    //现网秘钥
    private static final String mPrivateKey_product_test = "MIIJQgIBADANBgkqhkiG9w0BAQEFAASCCSwwggkoAgEAAoICAQCdO8oMKgBcj/qJjT6SzokW7AUJ9k3FUeh2I9ZCeO7+xZ7BZ2pxFZ3fZ+rI+WSoS4KMMHvUU3Bi2Va8/64iXxzJCp3HlaZNVtnGuGfRkcWacfA2+TYTguyIA8AcsPn5xL+L8JOXDU9axTD6sOs0KKqKvxPtSdwN2QbgTI4ucQVthDQ2bxZKk/5CRENGut5LGebfDa6VKlOSjAVcIobWUhE9HaVc4YPErBSxTfA6Mq5E+EcamHkXfDjzBXI6LBpf7dBlxdL6696/42nvaXiQXkdwJ3r1PBOUjk51G19Fnyl/b6RwN0iw8T06DU96DqBInFsLFoZUCj9gE356wGqwbNkjFR3mC3b1Gni6aK9iSXqOqZ+jEzO/LTyjKqKpykR541i48+AznPAAenaQ0MIIAIedYttZVJ95mxDiuCEci6pccJ0KN16OOZx7LKyrNWBn5oDKyGG3ERRl5huaOsGhrqYkw+DUcOUTMVtfzUVCP1Jvhw7z+hqLNGkSGrt7a5CvInA2tkVHi11Vc4D+1fQDv83Uvnr8hLuGYVF/8Nn57utklH6w4rIuITgY5HnN2n1xzy+dK4/TdRF/wBC+LLpT0QxoNJADuoPOt3r0ZUSPt8lqn/9sYvqoXX5Czt55EfuZRUb9J8TEsD2JKqtQJjx4v2udbsPv0QfSwpAaS03nA0kLfwIDAQABAoICACt9URpiN61iiYqoTalvhQ2ZBJ/Hx6UPTbv3l5jVOE2xvYKDJzbWIs+bP56NFKFUGWzLMET/OzOsJ8io87JAGock75U3uELmBeBoOxcFOeHJKAcckS9+ZAwO9YE6FjpWiCCdz0TVgqB5sF12t+e6Y8lypoFYj4wo/jTmF+GSk0zCZ2qy+ThxjL8pgG4826VsKaaCc0qA5ZLANe9RAXigRHJiE84H9llcu3B7PTnrsLYU8h3SFJRBYMMfO4QJlNX5wk2UFRIgUYFD1pZI1vcfjKTh1qmkD0pkviC4DHcGWgUMjTAYqnt+jk/TRKtfBkhvLuN3PHpcR0E8wxwSwq+/u6L+l6xtxsRB5o76EKijmiPFO+UdlpdKgZq5yrAnL/yOwAaIGrTg46kU8G3ejcPC5LrpKOQpkZ7AucuYhm57gOtnu/v27/9Ruem+KJZgcWqWkYCy/d0XGfj33hnD8bfzSn6oSFoFYsihHDxyLJnw2eIULJQwM8nd7XiIKWeWFi6vTBLZzoyVoiFb7bfQYXOIqrtfhbyfxLaRiDv+K+wtmZYxslhsiZaJW89sA/gWzOwJxxFYW7gzk+YL8Oia+MAgCvVzVGU2JL8nTYEkmMJM0s/HWRLZB5IKtpEr2rhVo7lYaEZcqg5IafB7idiyviZtHFk6UiS7xDNe4ohq8kgtyejRAoIBAQDxpwjVOGWy1Iwj1ER7w6eAne7OdI40TThkFPxZsbcu1gctEO8J30WYZnJM9F/g6G2YUwo63R/bNkryq8ZXAgf/C6GIbvALeCK4QlVg/dcwnqxpDOePrc2NH5VnQYrSCLR3sNiOTIerhQkjPEBM0Ta5kv7+bMIvaCqM9oSSSREucJ+LkbdZqiuTZrUMM9SIkqJLdXJvcg63LY+TJJxVZCB92KI0OvCPldkK/xV+Zo+MhY8x3uHblb3vO6Px9D8kOaxq8S8h/k0ftWs/blAdMuTzcMIDyxyxp91n1D/7zRzYghDSkjAHPVC+iSiViQ9d4kaEJewLzzzVhpKxrfbqd7dHAoIBAQCmkaPlZ2qT7q3X8p7du4tF/ayfFDmdMkjDSQdGdTEFMt6gyc18BhibLK2Bl112V3X7XwKQWXxjIaOWX49DB1Vv5WLS1g1p4JCMcoTQpTzO9rShMOjpmKUA8X0UTVHzVPn3uFyD+jPStVcf2/R3y9F+xRB/OyMcioXGNED1BQ997ETKnq8/QvW0rLb7g9NjmcLkNmpii/6A5723fKT3xYypEF7ULEM/NaLAnjypzkgsVcFTe0xcdVYs+58DA0XEofYYe6v1H7TbbHG3jhj/pce5HUXGdU9kXl6z03BX3WiUr1x7JzZ4VNDs5gDN93rnR85T2nyh+NWael1lIqea0JYJAoIBAQClzi0yV3L4I/xP7SpcHSAGENc1EyYrXryNdxS62kRNP49G7bKF/Is9CTXt9VL/95qTBI8lWmmsOHFuVkxNkNg5uBpKiYvs4q437VO1rBYFhynXHoKXw/IgnYYehgshF9XztgSwhnQkTLC7W3DnBDnfVKvfmHIYowlnFRJbaQT/70iZNA8w16D0j2k0CTAP0UTIL7qoGwNbzkgP9vPJZ10f3A9XdQVwD6oPcHyn8OkXyuA4oKwpxXG//xT7Q9I7IdNawUfMtDboxcrjh+YyUqRjIIAOqEN05i/1ON36AH+FUqEGSkXoAbswMN4G1DcV/NbTf02ZwMUF4UMv5KRhtmirAoIBABHPGoXpg7SjXUTsdN3iMmbeU3mCsRJEkREIGtYGq6IRqUnpqaWsBS96HGbxpxWDDmM86kpCtxDmRNZMC0YwX4siLGm8Zxy93NaXW+nu8Mx0BiYB07U+E85BA42LIsrwd/VracDWnHnX16PZYY75ZMG4EiZ4TS29BcaGSbeovdpJy6UaSERsRVb27G2Bz7UjeHnr833r198yZ89ZbU3sejiNPoZS4TG961PK11OUcZUD6jKhyS1NglQ25u5siCYY5vYBKwZ/SFf5hUMJ11RmBi+dmJs6aa2ihV+WqLlMO+VBxpKIQ8Oj1d6uTMG4xxQ5Ui8W+iJbN4NXt+qbRO5BhPkCggEAd/kf4OxSkb56yY5IrxJcWVRX0UPL2OPItbImvvTv+f52E0JMY71m7vyiBJlMsVUmPC5osXVHMwZyK6fgiJ4vLSBCSG9xdw54nxGPrMoJNuQ4+7Kf7yE6ZXNxONgTqgb9YeJXvc6bo3uCea4jnH6xwij9+ytQLX8oH1i3OcC/sXYo+5GhWcALvb2mmI8lJHBqob+Kg9nmbO4DiJz7chQnZSByZd9lP7GShl7TD3vN+KAwC3IZ99Jx7MTs6B0gGuIPblzaa2xNvihq474y6eS8uaKirr4wyz/Am6y3O2ecJoPZxm+KXuExYi5nZfiaqM0qHl1nAf/8fItXDgJrPa5x4w==";
    //测试环境秘钥
    private static final String mPrivateKey_pm_test = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCKvYvUAV3ctkUIBncKhIMSRES/gvtZBZBMx5awPN70WM4lL2lvThcczK/gJDF9s8OfOHkMlfLXtI2Tt3HKRvnTNzvYHt25zBAJOeZ2+yADZQ8xA09duiDos8U3i5rNTA95wxGhUce/RQn40JjSTSlukhfjN2WWNVBdPlFqOlZTCtW1MvwrqAT9ZyTmAcDiLr+jffQQsvBbcBjsKl8C7GaLu3KZSS2DRF1BSspALlHJ1N52yF94HjeTPRgOgkSRd7Jeo/PNRgRnHz6Qa75N1LKebYy1NXR+MXzA0GYjjiV52rlrGpQ2A/2HuAO3ZyCPAEQtgK27kxkyLNaY4N5UI74ZAgMBAAECggEAQ2GdSIDFak0np6ckJ3qGAdggH3boxap7E58Xo05c5gU/UTX+me0uMnGCtXQ+iRNGXczalW85+uMYo3ZDkH76FEfOC7+p5fOikiiJsp1yRdPOFfrKj/W2x+2PSdPGghB/r546sMN8JHvORQZiQjjxd18CtPqRnusTtcVvWw0sIbX4Xd0Ay4R7MWkLt2c+nvlhYfs4Jq8YdH8fJZBq7RHj9sdIUQwX6zG/IdjBePTNsZOFJ40EzNHAvHM1TvT7xNy92G1iG7AmAmf02gZz4JAffk6aXCO2xtypLVtcz0bvNy1dSIV/K8XLFIOCKt0XLAViafOUif+lN8eJF/slm7TNxQKBgQDQ7wZM8UqlF4A2XAD5ddSGSuyjsSgKJCER1HTPI7rhNF9T6ItizHXjbLZTnZSk35Wv2seri13dofwTS+gF8fJ/WF9ACkV/g0vVYsmheR9jKjR5dP7E4Fgr+H/GDqk/opfpUwq3zyPMrOGMW5Ms13n+Ye8EZ4z9IRB7N58a8/kp1wKBgQCp/o2IYl5JKVMPgv1opqwM59UXUS0DMK04zw1td9WnV3JC7e3XRFFCmj6/L2YCmhSpN0uSdZL356avDYdQS3eRndpB0PZrZ8Nc795nURnY33WPozjbuDwAqo00JdGRCvbyoaestn5VRV7OK/AeRXqGwXFjmVY3SfXlfWOo2++5jwKBgQCok5MT1cQSfGm4cndez9GQITfZw4C43fnItxEgaIXKW0VnIEQGjU25F+fsg0KB3NybrPxZzvMHdkE7GI227kZotVb1BtSYU8mF/FUPcfj/O/hm3x0IoLLDl5cQqJeqfnfvjE8ji4ApDnxVkTWogpstwrrlZN9/BYSUxoYbaypotQKBgGdQU4gt8IuaV+a3f3dYxHvbcgCHz0l/DefWvpxnFixr0v+mRsRrus81myjqj57JMgFdn8pVNor/+KevGyvLkdGoE/uoGftQxsT26z3zZjgOJw6y7l1q7NyiysqEqYbzGP6BDLzE9KayUFoRDg/3ve2kJ1uW13UmuBFPUYBQmrM1AoGAHAvfUMtHO4zoP1w4aTy9tLSkr+HkebgVvZMDVqB/NSuKfs9QHyLGjWtbtkTMa4OvWRugLbEA4QdiMqPWs/u6lYPcGuljRIetSJUyPjTlse68vcMgFoLOp9Z+YKcMU9aPCA7bQoZfPXwcb+CZ/uaCWtKqd/m7tJFESGI1wQnI098=";

    private WalletPassClient walletObjectsClient;
    private String issuerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sec_main);

    }

    @Override
    public void onConnectionFailed(ConnectionResult result) {
        Log.w(TAG, "onConnectionFailed: " + result);
    }

    //wallet kit 添卡方式
    public void saveToAndroid(View view) {
        Intent i = this.getIntent();
        String passObject = i.getStringExtra("passObject");
        System.out.println("passObject" + passObject);
        issuerId = i.getStringExtra("issuerId");
        System.out.println("issuerId:" + issuerId);
        String jwtStr = getJwtFromAppServer(passObject);
        CreateWalletPassRequest request = CreateWalletPassRequest.newBuilder()
                .setJwt(jwtStr)
                .build();
        Wallet.WalletConfig walletOptions = new Wallet.WalletConfig.PassBuilder()
                .setTheme(WalletCommonConstants.THEME_HW_LIGHT)
                .setEnvironment(WalletCommonConstants.ENVIRONMENT_PRODUCTION_RELEASE)
                .build();
        Log.i("testwalletKIT", "getWalletObjectsClient");
        walletObjectsClient = Wallet.getWalletPassClient(PassTestActivity.this, walletOptions);
        Task<AutoResolvableForegroundIntentResult> task = walletObjectsClient.createWalletPass(request);
        ResolveTaskHelper.excuteTask(task, PassTestActivity.this, SAVE_TO_ANDROID);
    }

    public void clickLinkToPay(View view) {
        Intent i = this.getIntent();
        String passObject = i.getStringExtra("passObject");
        System.out.println("passObject" + passObject);
        issuerId = i.getStringExtra("issuerId");
        String jwtStr = getJwtFromAppServer(passObject);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("hms://www.huawei.com/payapp/{"+ jwtStr+"}"));
        try{
            startActivityForResult(intent, SAVE_TO_ANDROID);
        }catch (ActivityNotFoundException e){
            Log.println(Log.ERROR,"HMS","HMS未安装正确:ActivityNotFoundException");
        }

    }

    //拉起wallet app 或者浏览器
    public void clickAppOrUriToPay(View view) {
        Intent ii = PassTestActivity.this.getIntent();
        String passObject = ii.getStringExtra("passObject");
        Log.i(TAG,"passObject" + passObject);
        issuerId = ii.getStringExtra("issuerId");
        String jwtStr = getJwtFromAppServer(passObject);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        //intent.setData(Uri.parse("http://walletkit.devoversea.hwcloudtest.cn/walletkit/consumer/pass/save/" + jwtStr));
        //intent.setData(Uri.parse("https://lfwalletkittest.hwcloudtest.cn:18444/walletkit/consumer/pass/save?jwt=" + Uri.encode(jwtStr)));
        intent.setData(Uri.parse("https://walletkit.testrussia.hwcloudtest.cn:18444/walletkit/consumer/pass/save?jwt=" + Uri.encode(jwtStr)));
        try{
            startActivity(intent);
        }catch (ActivityNotFoundException e){
            Log.println(Log.ERROR,"HMS","HMS未安装正确:ActivityNotFoundException");
            return;
        }
    }


    //查看卡券
    public  void  viewCard(View view){
        Intent ii = PassTestActivity.this.getIntent();
        String passId = ii.getStringExtra("passId");
        issuerId = ii.getStringExtra("issuerId");
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://lfwalletkittest.hwcloudtest.cn:18444/walletkit/consumer/pass/object?issuerId="+issuerId+"&objectId="+passId));
        try{
            startActivity(intent);
        }catch (ActivityNotFoundException e){
            Log.println(Log.ERROR,"HMS","HMS未安装正确:ActivityNotFoundException");
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case SAVE_TO_ANDROID:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        Toast.makeText(this, "save success", Toast.LENGTH_LONG).show();
                        break;
                    case Activity.RESULT_CANCELED:
                        Toast.makeText(this, "(Reason, 1：cancel by user 2：HMS not install or register)", Toast.LENGTH_LONG).show();
                        break;
                    default:
                        if (data != null) {
                            int errorCode =
                                    data.getIntExtra(
                                            WalletCommonConstants.EXTRA_ERROR_CODE, -1);
                            Toast.makeText(this, "fail, [" + errorCode + "]：" + analyzeErrorCode(errorCode), Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(this, "fail ：data is null ", Toast.LENGTH_LONG).show();
                        }
                        break;
                }
        }

    }

    private String analyzeErrorCode(int errorCode) {
        String tips = "";
        switch (errorCode) {
            case WalletCommonConstants.ERROR_CODE_SERVICE_UNAVAILABLE:
                tips = "服务不可用（网络访问服务异常）";
                break;
            case WalletCommonConstants.ERROR_CODE_INTERNAL_ERROR:
                tips = "内部错误";
                break;
            case WalletCommonConstants.ERROR_CODE_INVALID_PARAMETERS:
                tips = "参数错误或无效（重复加卡）";
                break;
            case WalletCommonConstants.ERROR_CODE_MERCHANT_ACCOUNT_ERROR:
                tips = "JWT验签失败";
                break;
            case WalletCommonConstants.ERROR_CODE_BUYER_ACCOUNT_ERROR:
                tips = "华为账号有误（账号无效或者鉴权失败）";
                break;
            case WalletCommonConstants.ERROR_CODE_UNSUPPORTED_API_REQUEST:
                tips = "不支持的API";
                break;
            case WalletCommonConstants.ERROR_CODE_OTHERS:
            default:
                tips = "未知错误";
                break;
        }
        return tips;
    }

    /**
     * 现网环境请替换以下代码，将passObject传至开发者服务器，使用wallet kit提供的服务端jar包生成对应的JWT数据，然后回传给客户端
     * 详细的服务端jar包使用请服务端demo
     *
     * @param passObject PASS对象
     * @return JWT数据
     */
    private String getJwtFromAppServer(String passObject){
        Map<String, String> signMap = JwtUtil.generateJwt(issuerId, mPrivateKey_product_test, passObject);
        String jwtStr = signMap.get("jwtStr");
        Log.i(TAG, "jwtStr:" + jwtStr);
        return jwtStr;
    }


}