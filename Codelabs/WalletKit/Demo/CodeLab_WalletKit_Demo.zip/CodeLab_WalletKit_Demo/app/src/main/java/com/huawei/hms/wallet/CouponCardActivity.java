package com.huawei.hms.wallet;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.huawei.hms.api.ConnectionResult;
import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.maps.model.LatLng;
import com.huawei.hms.wallet.apptest.R;
import com.huawei.hms.wallet.base.TextComponentInfo;
import com.huawei.hms.wallet.base.TimeDuration;
import com.huawei.hms.wallet.base.UriInfo;
import com.huawei.hms.wallet.base.WalletPassConstants;
import com.huawei.hms.wallet.base.WalletPassMessage;
import com.huawei.hms.wallet.util.BasisTimesUtils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CouponCardActivity  extends Activity implements HuaweiApiClient.OnConnectionFailedListener{

        private static final String TAG = "CouponCardActivity";
        public static final int SAVE_TO_ANDROID = 888;

        // passObject状态下拉框
        private Spinner spinner;
        private List<String> data_list;
        private ArrayAdapter<String> arr_adapter;
        int indext;
        private  String startTime = "";
        private  String endTime = "";


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.coupon_card_info);

            Button button = findViewById(R.id.clickSaveCouponData);
            //passObject状态下拉框
            spinner = (Spinner) findViewById(R.id.spinnerCoupon);
            //数据
            data_list = new ArrayList<String>();
            data_list.add("ACTIVE");
            data_list.add("COMPLETED");
            data_list.add("EXPIRED");
            data_list.add("INACTIVE");
            //适配器
            arr_adapter = new ArrayAdapter<String>(CouponCardActivity.this, android.R.layout.simple_spinner_item, data_list);
            //设置样式
            arr_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            //加载适配器
            spinner.setAdapter(arr_adapter);

            spinner.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {//选择item的选择点击监听事件
                public void onItemSelected(AdapterView<?> arg0, View arg1,
                                           int arg2, long arg3) {
                    // 获取选择状态索引值
                    indext = arg2;
                }

                public void onNothingSelected(AdapterView<?> arg0) {
                }
            });


            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TextView passTypeId = findViewById(R.id.typeIdentifierCoupon);
                    String typeId = passTypeId.getText().toString();
                    if (TextUtils.isEmpty(typeId)) {
                        Toast.makeText(CouponCardActivity.this, "passTypeIdentifier为空", Toast.LENGTH_LONG).show();
                        return;
                    }


                    TextView issuerIdView = findViewById(R.id.issuerIdCoupon);
                    String issuerId = issuerIdView.getText().toString();
                    if (TextUtils.isEmpty(issuerId)) {
                        Toast.makeText(CouponCardActivity.this, "issuerId为空", Toast.LENGTH_LONG).show();
                        return;
                    }

                    EditText passBarcodeAlternateText = findViewById(R.id.barcodeAlternateTextCoupon);
                    EditText passBarcodeType = findViewById(R.id.barcodeTypeCoupon);
                    EditText passBarcodeValue = findViewById(R.id.barcodeValueCoupon);
                    EditText passStyleIdentifierCoupon = findViewById(R.id.passStyleIdentifierCoupon);
                    String styleId =   passStyleIdentifierCoupon.getText().toString();
                    if (TextUtils.isEmpty(styleId)){
                        Toast.makeText(CouponCardActivity.this,"卡券类别为空",Toast.LENGTH_LONG).show();
                        return;
                    }

                    //serinumber
                    TextView organizationPassIdCoupon = findViewById(R.id.organizationPassIdCoupon);
                    String organizationPassId = organizationPassIdCoupon.getText().toString();
                    if (TextUtils.isEmpty(organizationPassId)) {
                        Toast.makeText(CouponCardActivity.this, "卡券唯一标识必填", Toast.LENGTH_LONG).show();
                        return;
                    }

                    //图片模块主图片URI
                    EditText imageModuleDataMainImageUrisCoupon = findViewById(R.id.imageModuleDataMainImageUrisCoupon);
                    EditText imageModuleDataMainImageUrisDesCoupon = findViewById(R.id.imageModuleDataMainImageUrisDesCoupon);
                    EditText imageModuleDataMainImageUrisCoupon1 = findViewById(R.id.imageModuleDataMainImageUrisCoupon1);
                    EditText imageModuleDataMainImageUrisDesCoupon1 = findViewById(R.id.imageModuleDataMainImageUrisDesCoupon1);


                    //发卡方名字
                    TextView passIssuerName = findViewById(R.id.passIssuerNameCoupon);
                    String IssuerNameCoupon = passIssuerName.getText().toString();
                    if (TextUtils.isEmpty(IssuerNameCoupon)) {
                        Toast.makeText(CouponCardActivity.this, "发卡方名字为空", Toast.LENGTH_LONG).show();
                        return;
                    }

                    //经纬度
                    EditText latitudeCoupon = findViewById(R.id.latitudeCoupon);
                    EditText longitudeCoupon = findViewById(R.id.longitudeCoupon);
                    EditText latitudeCoupon1 = findViewById(R.id.latitudeCoupon1);
                    EditText longitudeCoupon1 = findViewById(R.id.longitudeCoupon1);


                    //message消息
                    EditText messageHeaderCoupon = findViewById(R.id.messageHeaderCoupon);
                    EditText messageBodyCoupon = findViewById(R.id.messageBodyCoupon);
                    EditText messageHeaderCoupon1 = findViewById(R.id.messageHeaderCoupon1);
                    EditText messageBodyCoupon1 = findViewById(R.id.messageBodyCoupon1);


                    //文本消息
                    EditText textDataHeaderCoupon = findViewById(R.id.textDataHeaderCoupon);
                    EditText textDataBodyCoupon = findViewById(R.id.textDataBodyCoupon);
                    EditText textDataHeaderCoupon1 = findViewById(R.id.textDataHeaderCoupon1);
                    EditText textDataBodyCoupon1 = findViewById(R.id.textDataBodyCoupon1);


                    // 项目的名称
                    EditText programNameCoupon = findViewById(R.id.programNameCoupon);
                    String programName = programNameCoupon.getText().toString();
                    if (TextUtils.isEmpty(programName)) {
                        Toast.makeText(CouponCardActivity.this, "项目名称为空", Toast.LENGTH_LONG).show();
                        return;
                    }

                    //link 模块
                    EditText linkLableCoupon = findViewById(R.id.linkLableCoupon);
                    EditText linkUriCoupon = findViewById(R.id.linkUriCoupon);
                    EditText linkDesCoupon = findViewById(R.id.linkDesCoupon);
                    EditText linkLableCoupon1 = findViewById(R.id.linkLableCoupon1);
                    EditText linkUriCoupon1 = findViewById(R.id.linkUriCoupon1);
                    EditText linkDesCoupon1 = findViewById(R.id.linkDesCoupon1);

                    /*-------------------我是分割线-----------------------*/

                    //位置校验
                    Double latitud = 0.0;
                    Double longitud = 0.0;
                    String latitudeStr  = latitudeCoupon.getText().toString();
                    String longitudeStr = longitudeCoupon.getText().toString();
                    String latitudeStr1  = latitudeCoupon1.getText().toString();
                    String longitudeStr1 = longitudeCoupon1.getText().toString();

                    if (TextUtils.isEmpty(latitudeStr) || TextUtils.isEmpty(longitudeStr)) {
                        Toast.makeText(CouponCardActivity.this, "必填纬度或经度未输入", Toast.LENGTH_LONG).show();
                        return;

                    } else {
                        if (-90.0D <= Double.valueOf(latitudeStr) && Double.valueOf(latitudeStr) <= 90.0D && -180.0D <= Double.valueOf(longitudeStr) && Double.valueOf(longitudeStr) <= 180.0D) {
                            latitud = Double.valueOf(latitudeStr);
                            longitud = Double.valueOf(longitudeStr);
                        } else {
                            Toast.makeText(CouponCardActivity.this, "必填纬度或经度超过范围", Toast.LENGTH_LONG).show();
                            return;
                        }
                    }

                    LatLng location = new LatLng(latitud, longitud);
                    List<LatLng> locations = new ArrayList<>();
                    locations.add(location);


                    //状态
                    int state = 1;
                    switch (data_list.get(indext)) {
                        case "ACTIVE":
                            state = WalletPassConstants.PassState.ACTIVE;
                            break;
                        case "COMPLETED":
                            state = WalletPassConstants.PassState.COMPLETED;
                            break;
                        case "EXPIRED":
                            state = WalletPassConstants.PassState.EXPIRED;
                            break;
                        case "INACTIVE":
                            state = WalletPassConstants.PassState.INACTIVE;
                    }


                    //有效的时间间隔
                    Long start = 0L;
                    Long end = 0L;
                    Date date = new Date();
                    if (TextUtils.isEmpty(startTime)) {
                        Toast.makeText(CouponCardActivity.this, "生效时间未选择", Toast.LENGTH_LONG).show();
                        return;
                    }else {
                        start = BasisTimesUtils.getLongTimeOfYMD(startTime);
                    }

                    if (TextUtils.isEmpty(endTime)) {
                        Toast.makeText(CouponCardActivity.this, "失效时间未选择", Toast.LENGTH_LONG).show();
                        return;
                    }else {
                        end = BasisTimesUtils.getLongTimeOfYMD(endTime);
                    }

                    if (end <=start || end <= date.getTime()){
                        Toast.makeText(CouponCardActivity.this, "结束时间必须大于开始时间并且大于当前时间", Toast.LENGTH_LONG).show();
                        return;
                    }
                    TimeDuration mValidTimeDuration = new TimeDuration(start,end);


                    OfferWalletObject.PassBuilder builder=   OfferWalletObject.newPassBuilder();
                    builder.setPassTypeIdentifier(typeId)
                            .setPassBarcodeAlternateText(passBarcodeAlternateText.getText().toString())
                            .setPassBarcodeType(passBarcodeType.getText().toString())
                            .setPassBarcodeValue(passBarcodeValue.getText().toString())
                            .setPassStyleIdentifier(styleId)
                            .setOrganizationPassId(organizationPassId)
                            .setPassIssuerName(IssuerNameCoupon)
                            .setProgramName(programName)
                            .setPassState(state)
                            .setPassTimeDuration(mValidTimeDuration);


                    //图片模块主图片URI
                    List uris = new ArrayList();
                    String imageUris  = imageModuleDataMainImageUrisCoupon.getText().toString();
                    String imageDes = imageModuleDataMainImageUrisDesCoupon.getText().toString();
                    String imageUris1  = imageModuleDataMainImageUrisCoupon1.getText().toString();
                    String imageDes1 = imageModuleDataMainImageUrisDesCoupon1.getText().toString();
                    if (!TextUtils.isEmpty(imageUris) && !TextUtils.isEmpty(imageDes) && TextUtils.isEmpty(imageUris1) && TextUtils.isEmpty(imageDes1)){
                        builder.addImage(new UriInfo(imageUris,imageDes));
                    } else if (TextUtils.isEmpty(imageUris) && TextUtils.isEmpty(imageDes) && !TextUtils.isEmpty(imageUris1) && !TextUtils.isEmpty(imageDes1)){
                        builder.addImage(new UriInfo(imageUris1,imageDes1));
                    }else  if (!TextUtils.isEmpty(imageUris) && !TextUtils.isEmpty(imageDes) && !TextUtils.isEmpty(imageUris1) && !TextUtils.isEmpty(imageDes1)){
                        new UriInfo(imageUris1,imageDes1);
                        uris.add(new UriInfo(imageUris,imageDes));
                        uris.add(new UriInfo(imageUris1,imageDes1));
                        builder.addImageList(uris);
                    }

                    //加入成功后显示文本钱包对象消息
                    List messages = new ArrayList();
                    String mgeHeader  = messageHeaderCoupon.getText().toString();
                    String mgeBody = messageBodyCoupon.getText().toString();
                    String mgeHeader1  = messageHeaderCoupon1.getText().toString();
                    String mgeBody1 = messageBodyCoupon1.getText().toString();
                    if (!TextUtils.isEmpty(mgeHeader) && !TextUtils.isEmpty(mgeBody) && TextUtils.isEmpty(mgeHeader1) && TextUtils.isEmpty(mgeBody1)){
                        WalletPassMessage message = WalletPassMessage.newBuilder()
                                .setTitle(mgeHeader)
                                .setContent(mgeBody)
                                .build();
                        builder.addMessage(message);
                    } else if (TextUtils.isEmpty(mgeHeader) && TextUtils.isEmpty(mgeBody) && !TextUtils.isEmpty(mgeHeader1) && !TextUtils.isEmpty(mgeBody1)){
                        WalletPassMessage  message = WalletPassMessage.newBuilder()
                                .setTitle(mgeHeader1)
                                .setContent(mgeBody1)
                                .build();
                        builder.addMessage(message);

                    }else  if (!TextUtils.isEmpty(mgeHeader) && !TextUtils.isEmpty(mgeBody) && !TextUtils.isEmpty(mgeHeader1) && !TextUtils.isEmpty(mgeBody1)){
                        messages.add(WalletPassMessage.newBuilder()
                                .setTitle(mgeHeader)
                                .setContent(mgeBody)
                                .build());
                        messages.add(WalletPassMessage.newBuilder()
                                .setTitle(mgeHeader1)
                                .setContent(mgeBody1)
                                .build());
                        builder.addMessageList(messages);
                    }

                    //构建文本模块
                    List textModulesData = new ArrayList();
                    String textHeader  = textDataHeaderCoupon.getText().toString();
                    String textBody = textDataBodyCoupon.getText().toString();
                    String textHeader1  = textDataHeaderCoupon1.getText().toString();
                    String textBody1 = textDataBodyCoupon1.getText().toString();
                    if (!TextUtils.isEmpty(textHeader) && !TextUtils.isEmpty(textBody) && TextUtils.isEmpty(textHeader1) && TextUtils.isEmpty(textBody1)){
                        TextComponentInfo textModuleData = new TextComponentInfo(textHeader,textBody);
                        builder.addText(textModuleData);
                    } else if (TextUtils.isEmpty(textHeader) && TextUtils.isEmpty(textBody) && !TextUtils.isEmpty(textHeader1) && !TextUtils.isEmpty(textBody1)){
                        TextComponentInfo textModuleData = new TextComponentInfo(textHeader1,textBody1);
                        builder.addText(textModuleData);

                    }else if (!TextUtils.isEmpty(textHeader) && !TextUtils.isEmpty(textBody) && !TextUtils.isEmpty(textHeader1) && !TextUtils.isEmpty(textBody1)){
                        textModulesData.add(new TextComponentInfo(textHeader,textBody));
                        textModulesData.add(new TextComponentInfo(textHeader1,textBody1));
                        builder.addTextList(textModulesData);
                    }

                    //判断第二个位置是否为空 据此判断是添加集合还是添加单个
                    if (TextUtils.isEmpty(latitudeStr1) || TextUtils.isEmpty(longitudeStr1)) {
                        builder.addPassLocation(location);
                    } else {
                        if (-90.0D <= Double.valueOf(latitudeStr1) && Double.valueOf(latitudeStr1) <= 90.0D && -180.0D <= Double.valueOf(longitudeStr1) && Double.valueOf(longitudeStr1) <= 180.0D) {
                            double latitudSecond = Double.valueOf(latitudeStr1);
                            double  longitudSecond = Double.valueOf(longitudeStr1);
                            locations.add(new LatLng(latitudSecond,longitudSecond));
                            builder.addPassLocationList(locations);
                        } else {
                            Toast.makeText(CouponCardActivity.this, "可选的纬度或经度超过范围", Toast.LENGTH_LONG).show();
                            return;
                        }
                    }

                    //构造passLinkUris
                    String linkLable  = linkLableCoupon.getText().toString();
                    String linkUri = linkUriCoupon.getText().toString();
                    String linkDes  = linkDesCoupon.getText().toString();
                    String linkLable1 = linkLableCoupon1.getText().toString();
                    String linkUri1 = linkUriCoupon1.getText().toString();
                    String linkDes1  = linkDesCoupon1.getText().toString();
                    UriInfo uriInfo =   new UriInfo(linkUri,linkDes);
                    UriInfo uriInfo1 = new UriInfo(linkUri1,linkDes1);
                    builder.addPassLinkUris(linkLable,uriInfo);
                    builder.addPassLinkUris(linkLable1,uriInfo1);


                    OfferWalletObject wob = builder.build();

                    //显示方式声明Intent，直接启动SecondActivity
                    Intent intent = new Intent(CouponCardActivity.this, PassTestActivity.class);
                    intent.putExtra("passObject", wob.toJson());
                    intent.putExtra("passId", organizationPassId);
                    intent.putExtra("issuerId", issuerId);
                    intent.putExtra("typeId", typeId);
                    startActivity(intent);
                }
            });

        }

        @Override
        public void onConnectionFailed(ConnectionResult connectionResult) {

        }


        public  void  selectStartTime(View view){
            // 获取日历对象
            Calendar calendar = Calendar.getInstance();
            // 获取当前对应的年、月、日的信息
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH) + 1;
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            // 获取当前时间信息
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);


            //选择时间
            BasisTimesUtils.showDatePickerDialog(CouponCardActivity.this, "true", year, month, day, new BasisTimesUtils.OnDatePickerListener() {
                @Override
                public void onConfirm(int year, int month, int dayOfMonth) {
                    startTime = String.valueOf(year)+"-"+String.valueOf(month)+"-"+String.valueOf(dayOfMonth);


                }

                @Override
                public void onCancel() {
                    Toast.makeText(CouponCardActivity.this, "DatePickerDialog取消 ", Toast.LENGTH_SHORT).show();
                }
            });

        }

        public  void  selectEndTime(View view){
            // 获取日历对象
            Calendar calendar = Calendar.getInstance();
            // 获取当前对应的年、月、日的信息
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH) + 1;
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            // 获取当前时间信息
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);

            //选择时间
            BasisTimesUtils.showDatePickerDialog(CouponCardActivity.this, "true", year, month, day, new BasisTimesUtils.OnDatePickerListener() {
                @Override
                public void onConfirm(int year, int month, int dayOfMonth) {
                    endTime = String.valueOf(year)+"-"+String.valueOf(month)+"-"+String.valueOf(dayOfMonth);
                }

                @Override
                public void onCancel() {
                    Toast.makeText(CouponCardActivity.this, "DatePickerDialog取消 ", Toast.LENGTH_SHORT).show();
                }
            });

    }

}
