package com.huawei.hms.wallet.util;

import com.huawei.hms.wallet.pass.AppendFieldsSimple;
import com.huawei.hms.wallet.pass.BarCode;
import com.huawei.hms.wallet.pass.BaseFields;
import com.huawei.hms.wallet.pass.CommonFields;
import com.huawei.hms.wallet.pass.LocalizedLanguage;
import com.huawei.hms.wallet.pass.Locations;
import com.huawei.hms.wallet.pass.PassObject;
import com.huawei.hms.wallet.pass.PassSatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class LoyaltyObjectTest {

   /* public static String getNotUserJwtData() {
        PassSatus status = PassSatus.newPassBuilder()
                .setState("active")
                .setEffectTime("2019-11-13T00:00:00.111Z")
                .setExpireTime("2020-11-13T00:00:00.111Z")
                .build();

        BarCode barCode = BarCode.newPassBuilder()
                .setAlternateText("AlternateText")
                .setEncoding("UTF-8")
                .setShowCodeText("ShowCodeText")
                .setType("barCode_type")
                .setValue("barCode_value")
                .build();

        List<String> linkedPassIds = new ArrayList<>();
        linkedPassIds.add("4539640255875452");
        linkedPassIds.add("4539640255896443");
        ArrayList<Locations> locations = new ArrayList<>();
        Locations locations1 = Locations.newPassBuilder()
                .setLatitude("63.5")
                .setLongitude("101.2")
                .build();
        locations.add(locations1);

        ArrayList<CommonFields> commonFields = new ArrayList<>();
        CommonFields programLogo = CommonFields.newPassBuilder()
                .setKey("programLogo")
                .setValue("programLogo_url")
                .setLabel("Logo")
                .build();
        commonFields.add(programLogo);
        CommonFields issuerName = CommonFields.newPassBuilder()
                .setKey("issuerName")
                .setValue("class_issuerName")
                .setLabel("name")
                .setLocalizedLabel("issuerNameLocalizedLabel")
                .setLocalizedValue("issuerNameLocalizedValue")
                .build();
        commonFields.add(issuerName);
        CommonFields programName = CommonFields.newPassBuilder()
                .setKey("programName")
                .setValue("class_programName")
                .setLabel("name")
                .build();
        commonFields.add(programName);

        List<Object> appendFields = new ArrayList<>();
        AppendFieldsSimple backgroundColor = AppendFieldsSimple.newPassBuilder()
                .setKey("backgroundColor")
                .setValue("class_hexBackgroundColor")
                .setLabel("BackgroundColor")
                .build();
        appendFields.add(backgroundColor);
        AppendFieldsSimple points = AppendFieldsSimple.newPassBuilder()
                .setKey("points")
                .setValue("object_loyaltyPoints_balance")
                .setLabel("object_loyaltyPoints_label")
                .build();
        appendFields.add(points);

        ArrayList<LocalizedLanguage> localized = new ArrayList<>();
        LocalizedLanguage wallet = LocalizedLanguage.newPassBuilder()
                .setKey("wallet")
                .setLanguage("en-GB")
                .setValue("钱包")
                .build();
        localized.add(wallet);


        BaseFields fields = BaseFields.newPassBuilder()
                .setSrcPassIdentifier("65644548854542")
                .setSrcPassTypeIdentifier("exampleclass4")
                .setCountryCode("zh")
                .setIsUserDiy("0")
                .setStatus(status)
                .setBarCode(barCode)
                .setLinkedPassIds(null)
                .setLocations(locations)
                .addCommonFields(commonFields)
                .addAppendFields(appendFields)
                .addLocalizeds(localized)
                .build();


        PassObject passObject = PassObject.newPassBuilder()
                .setFormatVersion("10.0")
                .setPassVersion("2.0")
                .setPassTypeIdentifier("hwpass.com.huawei.wallet.pass.invoice")
                .setPassStyleIdentifier("exampleclass4")
                .setOrganizationName("class_issuerName")
                .setOrganizationPassId("3545614588567625")
                .setWebServiceURL("http://passentrust.devrussia.hwcloudtest.cn:8090/WiseCloudWalletPassService/passtools")
                .setAuthorizationToken("AdapterServer_token")
                .setSerialNumber("65644548854542")
                .addFields(fields)
                .build();


        String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAir2L1AFd3LZFCAZ3CoSDEkREv4L7WQWQTMeWsDze9FjOJS9pb04XHMyv4CQxfbPDnzh5DJXy17SNk7dxykb50zc72B7ducwQCTnmdvsgA2UPMQNPXbog6LPFN4uazUwPecMRoVHHv0UJ+NCY0k0pbpIX4zdlljVQXT5RajpWUwrVtTL8K6gE/Wck5gHA4i6/o330ELLwW3AY7CpfAuxmi7tymUktg0RdQUrKQC5RydTedshfeB43kz0YDoJEkXeyXqPzzUYEZx8+kGu+TdSynm2MtTV0fjF8wNBmI44ledq5axqUNgP9h7gDt2cgjwBELYCtu5MZMizWmODeVCO+GQIDAQAB";
        String privateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCKvYvUAV3ctkUIBncKhIMSRES/gvtZBZBMx5awPN70WM4lL2lvThcczK/gJDF9s8OfOHkMlfLXtI2Tt3HKRvnTNzvYHt25zBAJOeZ2+yADZQ8xA09duiDos8U3i5rNTA95wxGhUce/RQn40JjSTSlukhfjN2WWNVBdPlFqOlZTCtW1MvwrqAT9ZyTmAcDiLr+jffQQsvBbcBjsKl8C7GaLu3KZSS2DRF1BSspALlHJ1N52yF94HjeTPRgOgkSRd7Jeo/PNRgRnHz6Qa75N1LKebYy1NXR+MXzA0GYjjiV52rlrGpQ2A/2HuAO3ZyCPAEQtgK27kxkyLNaY4N5UI74ZAgMBAAECggEAQ2GdSIDFak0np6ckJ3qGAdggH3boxap7E58Xo05c5gU/UTX+me0uMnGCtXQ+iRNGXczalW85+uMYo3ZDkH76FEfOC7+p5fOikiiJsp1yRdPOFfrKj/W2x+2PSdPGghB/r546sMN8JHvORQZiQjjxd18CtPqRnusTtcVvWw0sIbX4Xd0Ay4R7MWkLt2c+nvlhYfs4Jq8YdH8fJZBq7RHj9sdIUQwX6zG/IdjBePTNsZOFJ40EzNHAvHM1TvT7xNy92G1iG7AmAmf02gZz4JAffk6aXCO2xtypLVtcz0bvNy1dSIV/K8XLFIOCKt0XLAViafOUif+lN8eJF/slm7TNxQKBgQDQ7wZM8UqlF4A2XAD5ddSGSuyjsSgKJCER1HTPI7rhNF9T6ItizHXjbLZTnZSk35Wv2seri13dofwTS+gF8fJ/WF9ACkV/g0vVYsmheR9jKjR5dP7E4Fgr+H/GDqk/opfpUwq3zyPMrOGMW5Ms13n+Ye8EZ4z9IRB7N58a8/kp1wKBgQCp/o2IYl5JKVMPgv1opqwM59UXUS0DMK04zw1td9WnV3JC7e3XRFFCmj6/L2YCmhSpN0uSdZL356avDYdQS3eRndpB0PZrZ8Nc795nURnY33WPozjbuDwAqo00JdGRCvbyoaestn5VRV7OK/AeRXqGwXFjmVY3SfXlfWOo2++5jwKBgQCok5MT1cQSfGm4cndez9GQITfZw4C43fnItxEgaIXKW0VnIEQGjU25F+fsg0KB3NybrPxZzvMHdkE7GI227kZotVb1BtSYU8mF/FUPcfj/O/hm3x0IoLLDl5cQqJeqfnfvjE8ji4ApDnxVkTWogpstwrrlZN9/BYSUxoYbaypotQKBgGdQU4gt8IuaV+a3f3dYxHvbcgCHz0l/DefWvpxnFixr0v+mRsRrus81myjqj57JMgFdn8pVNor/+KevGyvLkdGoE/uoGftQxsT26z3zZjgOJw6y7l1q7NyiysqEqYbzGP6BDLzE9KayUFoRDg/3ve2kJ1uW13UmuBFPUYBQmrM1AoGAHAvfUMtHO4zoP1w4aTy9tLSkr+HkebgVvZMDVqB/NSuKfs9QHyLGjWtbtkTMa4OvWRugLbEA4QdiMqPWs/u6lYPcGuljRIetSJUyPjTlse68vcMgFoLOp9Z+YKcMU9aPCA7bQoZfPXwcb+CZ/uaCWtKqd/m7tJFESGI1wQnI098=";
        System.out.println("hwLoyaltyObject: " + passObject.toJson());
        String issuerId = "300011981";
        Map<String, String> signMap = JwtUtil.generateJwt(issuerId, privateKey, passObject.toJson());
        String JwtStr = signMap.get("jwtStr");
        System.out.println("jwtStr:  " + JwtStr);
        String content = signMap.get("content");
        String sign = signMap.get("sign");
//        verifySign(publicKey, content, sign);
        return JwtStr;
    }*/
}
