/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 */

package com.huawei.hms.wallet.util;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;

import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import android.os.Build;
import android.support.annotation.RequiresApi;

import com.google.gson.Gson;

public class JwtUtil {

    /**
     * geneate public key and private key.
     *
     * @return public key and private Key.
     * @throws Exception Exception
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static Map<String, String> generateKeyPair() throws Exception {
        SecureRandom sr = new SecureRandom();
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048, sr);
        KeyPair kp = kpg.generateKeyPair();
        Key publicKey = kp.getPublic();
        byte[] publicKeyBytes = publicKey.getEncoded();
        String pub = Base64.getEncoder().encodeToString(publicKeyBytes);
        Key privateKey = kp.getPrivate();
        byte[] privateKeyBytes = privateKey.getEncoded();
        String pri = Base64.getEncoder().encodeToString(privateKeyBytes);
        Map<String, String> map = new HashMap<String, String>(16);
        map.put("publicKey", pub);
        map.put("privateKey", pri);
        return map;
    }

    /**
     * genate JWT,
     *
     * @param issuerId   Developer Alliance ID
     * @param privateKey private Key
     * @param claims     JWT contain Object.
     * @return content:data part, sign: sign part,
     */
    private static Map<String, String> generateJwt(String issuerId, String privateKey, Map<String, Object> claims) {
        String id = "jwt";
        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);
        JwtBuilder builder = Jwts.builder().setClaims(claims).setId(id).setIssuer(issuerId).setIssuedAt(now);
        String userToken = builder.compact();
        String content = userToken.substring(0, userToken.length() - 1);
        String sign = RSA.sign(content, privateKey, "");
        Map<String, String> map = new HashMap<String, String>(16);
        map.put("content", content);
        map.put("sign", sign);
        map.put("jwtStr", userToken + sign);
        return map;
    }

    public static Map<String, String> generateJwt(String issuerId, String privateKey, String jwt) {
        Gson gson = new Gson();
        Map<String, Object> claimsLoyaltyObject = gson.fromJson(jwt, Map.class);
        return generateJwt(issuerId, privateKey, claimsLoyaltyObject);
    }
}
